public class CMYKtoRGB {
    public static void main(String[] args){
        double C = Double.parseDouble(args[0]);
        double M = Double.parseDouble(args[1]);
        double Y = Double.parseDouble(args[2]);
        double K = Double.parseDouble(args[3]);

        double W = 1- K;

        double R = 255 * W * (1 - C);
        double G = 255 * W * (1- M);
        double B = 255 * W * (1 - Y);

        int red = (int) Math.round(R);
        int green = (int) Math.round(G);
        int blue = (int) Math.round(B);

        System.out.println("red = " + red);
        System.out.println("green = " + green);
        System.out.println("blue = " + blue);
    }
}
